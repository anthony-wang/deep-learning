# To submit:

* Go to the first-neural-network directory (`cd first-neural-network`)
* Open up a terminal and run `udacity submit first-neural-network`